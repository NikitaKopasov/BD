<?php require_once("MySiteDB.php"); ?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Главная страница сайта</title>
    </head>
<body>
    <site style="text-align:center;">
    <menu>
        <button type="button"> Вход</button>
        <button type="button"> Новая заметка</button>
        <button type="button"> Отправить сообщение</button>
        <button type="button"> Добавить фото</button>
        <a href="inform.php"><button type="button"> Статистика</button></a>
        <button type="button"> Администратору</button>
        <button type="button"> Выход</button> <br>
    </menu>
    <p><b>Рад приветствовать вас <br>на страницах моего сайта, посвященного путешествиям. </b></p>
</site>
<?php
        $query = "SELECT * FROM notes";
        $select_note = mysqli_query($link, $query);
            while ($note = mysqli_fetch_array($select_note))
            {
                echo $note ['id'], "<br>"; ?>
                <a href="comments.php?note=<?php echo $note['id']; ?>">
                <?php echo $note ['title'], "<br>";?></a>
                <?php
                echo $note ['created'], "<br>";
                echo $note ['article'], "<br>";
            }
    ?>
</body>
</html>