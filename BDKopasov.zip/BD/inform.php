<html>
    <head>

    </head>
    <body>
        <table style="border-collapse:collapse;">
            <tr>
                <th style ="border: 1px solid black;">
                   <p align="left"> Полезная информация: </p>
                </th>
            </tr>
            <tr>
                <td style ="border: 1px solid black;">
                    Сделанно записей - <br>
                    Оставлено комментариев - <br>
                    За последний месяц  я создал записей - <br>
                    За последний месяц оставленно комментариев - <br>
                    Моя последняя запись - <br>
                    Самая обсуждаемая запись - 
                </td>
            </tr>
        </table>
    </body>
</html>